<?php
const BASE='../';
require __DIR__.'/../includes/bootstrap.php';
$ip=$_SERVER['REMOTE_ADDR']??''; $err='';
if(isset($_GET['out'])){ session_destroy(); header('Location: index.php'); exit; }
if(empty($_SESSION['admin'])){
  if($_SERVER['REQUEST_METHOD']==='POST'){
    csrf_check();
    $pdo->prepare("DELETE FROM attempts WHERE ts<?")->execute([time()-900]);
    $c=$pdo->prepare("SELECT COUNT(*) FROM attempts WHERE ip=?"); $c->execute([$ip]);
    if($c->fetchColumn()>=5) $err='Слишком много попыток. Подождите 15 минут.';
    else{
      $q=$pdo->prepare("SELECT * FROM admins WHERE username=?"); $q->execute([trim($_POST['u']??'')]); $a=$q->fetch();
      if($a && password_verify($_POST['p']??'',$a['pass_hash'])){ session_regenerate_id(true); $_SESSION['admin']=$a['id']; $pdo->prepare("DELETE FROM attempts WHERE ip=?")->execute([$ip]); header('Location: index.php'); exit; }
      $pdo->prepare("INSERT INTO attempts(ip,ts) VALUES(?,?)")->execute([$ip,time()]); $err='Неверный логин или пароль';
    }
  }
  ?><!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>Вход</title><link rel="stylesheet" href="../assets/css/style.css"></head>
  <body class="adm"><form method="post" class="box panel"><h1>Вход в админ-панель</h1><?php if($err) echo '<div class="flash bad">'.e($err).'</div>'; echo csrf_field(); ?>
  <label>Логин<input name="u" required autofocus></label><label>Пароль<input type="password" name="p" required></label><button class="btn">Войти</button></form></body></html><?php exit;
}
$fields=['project_name'=>['Название проекта','i'],'tagline'=>['Слоган','i'],'hero_title'=>['Заголовок на баннере','i'],'hero_text'=>['Текст на баннере','t'],'about_title'=>['Заголовок «О проекте»','i'],'description'=>['Описание проекта','t'],'shots_title'=>['Заголовок скриншотов','i'],'dl_title'=>['Заголовок блока скачивания','i'],'footer'=>['Текст в подвале','i'],'telegram'=>['Ссылка Telegram','i'],'vk'=>['Ссылка VK','i'],'discord'=>['Ссылка Discord','i'],'youtube'=>['Ссылка YouTube','i']];
$colors=['accent'=>'Основной цвет','accent2'=>'Второй цвет градиента','bg'=>'Цвет фона'];
$flash=$_SESSION['flash']??null; unset($_SESSION['flash']); $t=$_GET['t']??'main';
if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_check(); $a=$_POST['a']??'';
  try{
    if($a==='save'){
      foreach($fields as $k=>$_){ $v=trim($_POST[$k]??''); if(in_array($k,['telegram','vk','discord','youtube'],true)&&$v!==''&&!preg_match('~^https?://~i',$v)) throw new Exception('Ссылки должны начинаться с http:// или https://'); save_setting($k,$v); }
      foreach($colors as $k=>$_){ if(preg_match('/^#[0-9a-f]{6}$/i',$_POST[$k]??'')) save_setting($k,$_POST[$k]); }
      save_setting('logo_h',(string)max(20,min(120,(int)($_POST['logo_h']??40))));
      foreach(['logo'=>['png','jpg','jpeg','webp',2000000],'favicon'=>['png','ico',500000],'banner'=>['png','jpg','jpeg','webp',8000000]] as $k=>$r){
        $max=array_pop($r);
        if(!empty($_POST['rm_'.$k])){ del_file(setting($k)); save_setting($k,''); }
        $p=upload($_FILES[$k]??[],$r,$max,'img'); if($p){ del_file(setting($k)); save_setting($k,$p); }
      }
      $_SESSION['flash']='Настройки сохранены';
    }elseif($a==='shots'){
      $n=0; foreach(($_FILES['shots']['name']??[]) as $i=>$_){
        $f=[]; foreach(['name','type','tmp_name','error','size'] as $x) $f[$x]=$_FILES['shots'][$x][$i];
        $p=upload($f,['png','jpg','jpeg','webp'],6000000,'shots'); if($p){ $pdo->prepare("INSERT INTO screenshots(path) VALUES(?)")->execute([$p]); $n++; }
      }
      $_SESSION['flash']="Добавлено скриншотов: $n";
    }elseif($a==='shot_del'){
      $q=$pdo->prepare("SELECT path FROM screenshots WHERE id=?"); $q->execute([(int)$_POST['id']]); if($p=$q->fetchColumn()){ del_file($p); $pdo->prepare("DELETE FROM screenshots WHERE id=?")->execute([(int)$_POST['id']]); }
      $_SESSION['flash']='Скриншот удалён';
    }elseif($a==='apk'){
      $name=preg_replace('/[^A-Za-z0-9_.-]+/','_',trim($_POST['apk_name']??'')); if($name==='') throw new Exception('Укажите название файла (латиницей)');
      save_setting('apk_name',$name); save_setting('version',trim($_POST['version']??'1.0.0'));
      $p=upload($_FILES['apk']??[],['apk'],500*1048576,'apk');
      if($p){ $old=setting('apk_file'); save_setting('apk_file',$p); save_setting('apk_size',(string)filesize(ROOT.'/'.$p)); save_setting('apk_date',date('d.m.Y H:i')); del_file($old); }
      $_SESSION['flash']='APK сохранён';
    }elseif($a==='apk_del'){
      del_file(setting('apk_file')); foreach(['apk_file'=>'','apk_size'=>'0','apk_date'=>''] as $k=>$v) save_setting($k,$v); $_SESSION['flash']='APK удалён';
    }elseif($a==='reset_dl'){ save_setting('downloads','0'); $_SESSION['flash']='Счётчик сброшен';
    }elseif($a==='pass'){
      $q=$pdo->prepare("SELECT * FROM admins WHERE id=?"); $q->execute([$_SESSION['admin']]); $u=$q->fetch();
      if(!password_verify($_POST['old']??'',$u['pass_hash'])) throw new Exception('Текущий пароль неверный');
      if(strlen($_POST['new']??'')<8||$_POST['new']!==($_POST['new2']??'')) throw new Exception('Новый пароль: минимум 8 символов, оба поля должны совпадать');
      $pdo->prepare("UPDATE admins SET pass_hash=? WHERE id=?")->execute([password_hash($_POST['new'],PASSWORD_DEFAULT),$u['id']]); $_SESSION['flash']='Пароль изменён';
    }
  }catch(Exception $x){ $_SESSION['flash']='!'.$x->getMessage(); }
  header('Location: index.php?t='.urlencode($t)); exit;
}
$s=settings();
?><!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>Админ-панель</title><link rel="stylesheet" href="../assets/css/style.css">
<style>:root{--a:<?=e($s['accent'])?>;--b:<?=e($s['accent2'])?>}</style></head><body class="adm"><div class="wrap">
<h1>Админ-панель</h1>
<div class="tabs"><?php foreach(['main'=>'Оформление и тексты','shots'=>'Скриншоты','apk'=>'APK','stats'=>'Статистика','pass'=>'Пароль'] as $k=>$l) echo '<a class="'.($t===$k?'on':'').'" href="?t='.$k.'">'.$l.'</a>'; ?><a href="../" target="_blank">Открыть сайт</a><a href="?out=1">Выйти</a></div>
<?php if($flash) echo '<div class="flash'.($flash[0]==='!'?' bad':'').'">'.e(ltrim($flash,'!')).'</div>';
if($t==='main'): ?>
<form method="post" enctype="multipart/form-data"><?=csrf_field()?><input type="hidden" name="a" value="save">
<div class="panel"><h3>Логотип, favicon, баннер</h3>
<label>Логотип (PNG, JPG, WebP до 2 МБ)<?php if($s['logo']) echo '<img class="cur" src="../'.e($s['logo']).'" alt="">'; ?><input type="file" name="logo" accept="image/png,image/jpeg,image/webp"></label>
<?php if($s['logo']) echo '<label><input type="checkbox" name="rm_logo" value="1"> Удалить логотип (покажется название текстом)</label>'; ?>
<label>Высота логотипа в шапке, px (20–120)<input type="number" name="logo_h" min="20" max="120" value="<?=(int)$s['logo_h']?>"></label>
<label>Favicon (PNG или ICO до 500 КБ)<?php if($s['favicon']) echo '<img class="cur" src="../'.e($s['favicon']).'" alt="">'; ?><input type="file" name="favicon" accept="image/png,image/x-icon"></label>
<?php if($s['favicon']) echo '<label><input type="checkbox" name="rm_favicon" value="1"> Удалить favicon</label>'; ?>
<label>Главный баннер (до 8 МБ)<?php if($s['banner']) echo '<img class="cur" src="../'.e($s['banner']).'" alt="">'; ?><input type="file" name="banner" accept="image/png,image/jpeg,image/webp"></label>
<?php if($s['banner']) echo '<label><input type="checkbox" name="rm_banner" value="1"> Удалить баннер</label>'; ?></div>
<div class="panel"><h3>Цвета</h3><div class="row"><?php foreach($colors as $k=>$l) echo '<label>'.$l.'<input type="color" name="'.$k.'" value="'.e($s[$k]).'"></label>'; ?></div></div>
<div class="panel"><h3>Тексты и ссылки</h3><?php foreach($fields as $k=>[$l,$ty]) echo '<label>'.$l.($ty==='t'?'<textarea name="'.$k.'">'.e($s[$k]).'</textarea>':'<input name="'.$k.'" value="'.e($s[$k]).'">').'</label>'; ?></div>
<button class="btn">Сохранить</button></form>
<?php elseif($t==='shots'): ?>
<form method="post" enctype="multipart/form-data" class="panel"><?=csrf_field()?><input type="hidden" name="a" value="shots"><h3>Добавить скриншоты</h3>
<label>Можно выбрать сразу несколько (PNG, JPG, WebP до 6 МБ каждый)<input type="file" name="shots[]" multiple required accept="image/png,image/jpeg,image/webp"></label><button class="btn">Загрузить</button></form>
<div class="panel"><h3>Текущие скриншоты</h3><div class="thumbs"><?php $r=$pdo->query("SELECT * FROM screenshots ORDER BY id")->fetchAll(); if(!$r) echo '<p>Скриншотов пока нет.</p>';
foreach($r as $x) echo '<figure><img src="../'.e($x['path']).'" alt=""><form method="post" onsubmit="return confirm(\'Удалить скриншот?\')">'.csrf_field().'<input type="hidden" name="a" value="shot_del"><input type="hidden" name="id" value="'.(int)$x['id'].'"><button class="btn sm red">Удалить</button></form></figure>'; ?></div></div>
<?php elseif($t==='apk'): ?>
<div class="panel"><h3>Текущий APK</h3><?php if($s['apk_file']) echo '<p>Файл: <b>'.e($s['apk_name']).'.apk</b><br>Версия: <b>'.e($s['version']).'</b><br>Размер: <b>'.fmt_size($s['apk_size']).'</b><br>Обновлён: <b>'.e($s['apk_date']).'</b><br>Скачиваний: <b>'.(int)$s['downloads'].'</b></p><form method="post" onsubmit="return confirm(\'Удалить APK?\')">'.csrf_field().'<input type="hidden" name="a" value="apk_del"><button class="btn sm red">Удалить APK</button></form>'; else echo '<p>APK не загружен.</p>'; ?></div>
<form method="post" enctype="multipart/form-data" class="panel"><?=csrf_field()?><input type="hidden" name="a" value="apk"><h3>Загрузить или заменить APK</h3>
<label>Название файла (без .apk)<input name="apk_name" value="<?=e($s['apk_name'])?>" required></label>
<label>Версия игры<input name="version" value="<?=e($s['version'])?>" required></label>
<label>Файл APK (оставьте пустым, чтобы изменить только название и версию)<input type="file" name="apk" accept=".apk"></label>
<p class="muted">Лимит хостинга сейчас: загрузка до <?=e(ini_get('upload_max_filesize'))?>, запрос до <?=e(ini_get('post_max_size'))?>.</p><button class="btn">Сохранить</button></form>
<?php elseif($t==='stats'): $tot=(int)$pdo->query("SELECT COALESCE(SUM(cnt),0) FROM visits")->fetchColumn(); $td=(int)$pdo->query("SELECT COALESCE(SUM(cnt),0) FROM visits WHERE day=CURDATE()")->fetchColumn(); ?>
<div class="panel"><h3>Статистика</h3><p>Посещений всего: <b><?=$tot?></b><br>Посещений сегодня: <b><?=$td?></b><br>Скачиваний APK: <b><?=(int)$s['downloads']?></b></p>
<form method="post" onsubmit="return confirm('Сбросить счётчик скачиваний?')"><?=csrf_field()?><input type="hidden" name="a" value="reset_dl"><input type="hidden" name="t" value="stats"><button class="btn sm red">Сбросить скачивания</button></form></div>
<div class="panel"><h3>Последние 14 дней</h3><table><tr><th>Дата</th><th>Посещения</th></tr><?php foreach($pdo->query("SELECT day,cnt FROM visits ORDER BY day DESC LIMIT 14") as $x) echo '<tr><td>'.e($x['day']).'</td><td>'.(int)$x['cnt'].'</td></tr>'; ?></table></div>
<?php else: ?>
<form method="post" class="panel"><?=csrf_field()?><input type="hidden" name="a" value="pass"><input type="hidden" name="t" value="pass"><h3>Смена пароля</h3>
<label>Текущий пароль<input type="password" name="old" required></label><label>Новый пароль (от 8 символов)<input type="password" name="new" required minlength="8"></label><label>Повторите новый пароль<input type="password" name="new2" required></label><button class="btn">Изменить пароль</button></form>
<?php endif; ?></div></body></html>
