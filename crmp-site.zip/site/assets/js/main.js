(function(){
if(/iPhone|iPad|iPod/i.test(navigator.userAgent)){var n=document.getElementById('ios-note');if(n)n.hidden=false;}
var lb=document.getElementById('lb'),im=lb.querySelector('img');
document.querySelectorAll('.shot').forEach(function(a){a.addEventListener('click',function(e){e.preventDefault();im.src=a.href;lb.hidden=false;});});
lb.addEventListener('click',function(){lb.hidden=true;});
document.addEventListener('keydown',function(e){if(e.key==='Escape')lb.hidden=true;});
})();
