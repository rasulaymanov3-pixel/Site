<?php
const BASE='';
require __DIR__.'/includes/bootstrap.php';
$f=setting('apk_file');
if($f===''||str_contains($f,'..')||!is_file(ROOT.'/'.$f)){ http_response_code(404); die('APK ещё не загружен'); }
$pdo->exec("UPDATE settings SET v=v+1 WHERE k='downloads'");
$n=preg_replace('/[^A-Za-z0-9_.-]+/','_',setting('apk_name','game')).'.apk';
header('Content-Type: application/vnd.android.package-archive');
header('Content-Disposition: attachment; filename="'.$n.'"');
header('Content-Length: '.filesize(ROOT.'/'.$f));
header('X-Content-Type-Options: nosniff');
readfile(ROOT.'/'.$f);
