<?php
const BASE='';
require __DIR__.'/includes/bootstrap.php';
if(empty($_SESSION['v'])){ $_SESSION['v']=1; $pdo->exec("INSERT INTO visits(day,cnt) VALUES(CURDATE(),1) ON DUPLICATE KEY UPDATE cnt=cnt+1"); }
$s=settings(); $shots=$pdo->query("SELECT path FROM screenshots ORDER BY id")->fetchAll(PDO::FETCH_COLUMN);
$has=$s['apk_file']!==''; $soc=['telegram'=>'Telegram','vk'=>'VK','discord'=>'Discord','youtube'=>'YouTube'];
?><!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=e($s['project_name'])?></title><meta name="description" content="<?=e(mb_substr($s['hero_text'],0,150))?>">
<?php if($s['favicon']) echo '<link rel="icon" href="'.e($s['favicon']).'">'; ?>
<link rel="stylesheet" href="assets/css/style.css">
<style>:root{--a:<?=e($s['accent'])?>;--b:<?=e($s['accent2'])?>;--bg:<?=e($s['bg'])?>}</style></head>
<body><header class="top"><a class="brand" href="#">
<?php if($s['logo']) echo '<img src="'.e($s['logo']).'" alt="" style="height:'.(int)$s['logo_h'].'px">'; else echo '<span>'.e($s['project_name']).'</span>'; ?></a>
<nav><a href="#about">О проекте</a><a href="#shots">Скриншоты</a><a href="#download">Скачать</a></nav></header>
<section class="hero"<?php if($s['banner']) echo ' style="--img:url(\''.e($s['banner']).'\')"'; ?>><div class="hero-in">
<h1><?=e($s['hero_title'])?></h1><p><?=e($s['hero_text'])?></p>
<a class="btn" href="#download">Скачать для Android</a></div></section>
<section id="about" class="sec"><h2><?=e($s['about_title'])?></h2><p class="lead"><?=nl2br(e($s['description']))?></p></section>
<section id="shots" class="sec"><h2><?=e($s['shots_title'])?></h2>
<?php if(!$shots) echo '<p class="muted">Скриншоты пока не добавлены.</p>'; ?>
<div class="grid"><?php foreach($shots as $p) echo '<a href="'.e($p).'" class="shot"><img loading="lazy" src="'.e($p).'" alt="Скриншот"></a>'; ?></div></section>
<section id="download" class="sec"><div class="dl"><div><h2><?=e($s['dl_title'])?></h2>
<p class="muted" id="ios-note" hidden>Установочный файл подходит только для Android. Откройте страницу на Android-устройстве.</p>
<ul class="meta"><li>Версия <b><?=e($s['version'])?></b></li>
<?php if($has): ?><li>Размер <b><?=fmt_size($s['apk_size'])?></b></li><li>Обновлено <b><?=e($s['apk_date'])?></b></li><li>Скачиваний <b><?=(int)$s['downloads']?></b></li><?php endif; ?></ul></div>
<?php if($has) echo '<a class="btn big" href="download.php">Скачать APK</a>'; else echo '<span class="btn big off">Файл скоро появится</span>'; ?></div>
<div class="soc"><?php foreach($soc as $k=>$l) if($s[$k]!=='') echo '<a class="chip" target="_blank" rel="noopener" href="'.e($s[$k]).'">'.$l.'</a>'; ?></div></section>
<footer><?=e($s['footer'])?></footer><div id="lb" hidden><img alt=""></div><script src="assets/js/main.js"></script></body></html>
