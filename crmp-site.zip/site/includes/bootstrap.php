<?php
declare(strict_types=1);
session_set_cookie_params(['httponly'=>true,'samesite'=>'Lax','secure'=>!empty($_SERVER['HTTPS'])]);
session_start();
define('ROOT', dirname(__DIR__));
if (!is_file(ROOT.'/config/config.php')) { header('Location: '.BASE.'install/'); exit; }
$cfg = require ROOT.'/config/config.php';
$pdo = new PDO("mysql:host={$cfg['host']};dbname={$cfg['name']};charset=utf8mb4", $cfg['user'], $cfg['pass'],
  [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
function e($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function settings(): array { static $s=null; global $pdo; if($s===null) $s=$pdo->query("SELECT k,v FROM settings")->fetchAll(PDO::FETCH_KEY_PAIR); return $s; }
function setting(string $k, string $d=''): string { return settings()[$k] ?? $d; }
function save_setting(string $k, string $v): void { global $pdo; $pdo->prepare("REPLACE INTO settings(k,v) VALUES(?,?)")->execute([$k,$v]); }
function csrf(): string { if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function csrf_field(): string { return '<input type="hidden" name="csrf" value="'.csrf().'">'; }
function csrf_check(): void { if(!hash_equals($_SESSION['csrf']??'', $_POST['csrf']??'')) { http_response_code(403); die('CSRF'); } }
function fmt_size($b): string { $b=(float)$b; return $b>=1048576 ? round($b/1048576,1).' МБ' : round($b/1024).' КБ'; }
function del_file(string $p): void { if($p!=='' && str_starts_with($p,'uploads/') && !str_contains($p,'..')) @unlink(ROOT.'/'.$p); }
function upload(array $f, array $ext, int $max, string $dir): ?string {
  if(empty($f['tmp_name']) || ($f['error']??4)===4) return null;
  if($f['error']!==0 || !is_uploaded_file($f['tmp_name'])) throw new Exception('Ошибка загрузки (проверьте лимиты PHP на хостинге)');
  if($f['size']>$max) throw new Exception('Файл больше допустимого размера: '.fmt_size($max));
  $e=strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
  if(!in_array($e,$ext,true)) throw new Exception('Недопустимый тип файла. Разрешено: '.implode(', ',$ext));
  if(in_array($e,['png','jpg','jpeg','webp'],true) && !@getimagesize($f['tmp_name'])) throw new Exception('Файл не является изображением');
  if($e==='apk' && file_get_contents($f['tmp_name'],false,null,0,2)!=='PK') throw new Exception('Файл не похож на APK');
  $name=bin2hex(random_bytes(10)).'.'.$e;
  if(!move_uploaded_file($f['tmp_name'], ROOT."/uploads/$dir/$name")) throw new Exception('Не удалось сохранить файл. Проверьте права на папку uploads');
  return "uploads/$dir/$name";
}
