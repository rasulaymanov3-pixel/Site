<?php
declare(strict_types=1);
$root=dirname(__DIR__); $h=fn($s)=>htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');
if(is_file($root.'/config/install.lock')){ http_response_code(403); die('<meta charset="utf-8"><body style="font-family:sans-serif;background:#0a0a12;color:#fff;padding:40px">Установка уже выполнена. Для повторной установки удалите config/config.php и config/install.lock.'); }
$checks=['PHP 8.0+ (у вас '.PHP_VERSION.')'=>version_compare(PHP_VERSION,'8.0.0','>='),'Расширение pdo_mysql'=>extension_loaded('pdo_mysql'),'Функции работы с изображениями'=>function_exists('getimagesize'),'Запись в config/'=>is_writable($root.'/config'),'Запись в uploads/'=>is_writable($root.'/uploads')];
$pass=!in_array(false,$checks,true); $err=''; $v=['host'=>'localhost','name'=>'','user'=>'','login'=>'admin','project'=>'My Project'];
if($pass && $_SERVER['REQUEST_METHOD']==='POST'){
  foreach($v as $k=>$_) $v[$k]=trim($_POST[$k]??$v[$k]); $dbpass=$_POST['dbpass']??''; $ap=$_POST['apass']??'';
  try{
    if(!preg_match('/^[A-Za-z0-9_.-]{3,32}$/',$v['login'])) throw new Exception('Логин: 3–32 символа, латиница, цифры, _ . -');
    if(strlen($ap)<8) throw new Exception('Пароль администратора: минимум 8 символов');
    if($ap!==($_POST['apass2']??'')) throw new Exception('Пароли не совпадают');
    $pdo=new PDO("mysql:host={$v['host']};dbname={$v['name']};charset=utf8mb4",$v['user'],$dbpass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
    $pdo->exec("CREATE TABLE IF NOT EXISTS settings(k VARCHAR(64) PRIMARY KEY, v TEXT) CHARACTER SET utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS admins(id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(32) UNIQUE, pass_hash VARCHAR(255)) CHARACTER SET utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS screenshots(id INT AUTO_INCREMENT PRIMARY KEY, path VARCHAR(255)) CHARACTER SET utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS visits(day DATE PRIMARY KEY, cnt INT NOT NULL DEFAULT 0) CHARACTER SET utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS attempts(ip VARCHAR(45), ts INT, KEY(ip)) CHARACTER SET utf8mb4");
    $pdo->prepare("INSERT INTO admins(username,pass_hash) VALUES(?,?)")->execute([$v['login'],password_hash($ap,PASSWORD_DEFAULT)]);
    $d=['project_name'=>$v['project'],'tagline'=>'','hero_title'=>'Добро пожаловать в '.$v['project'],'hero_text'=>'Мобильный игровой проект. Скачайте клиент и начните играть уже сегодня.','about_title'=>'О проекте','description'=>'Демонстрационный текст. Замените его в админ-панели: расскажите об особенностях сервера, работах, бизнесах и событиях.','shots_title'=>'Скриншоты','dl_title'=>'Скачать игру','footer'=>'© '.date('Y').' '.$v['project'],'version'=>'1.0.0','apk_name'=>preg_replace('/[^A-Za-z0-9_-]+/','_',$v['project']),'accent'=>'#7c3aed','accent2'=>'#ec4899','bg'=>'#0a0a12','logo_h'=>'40','telegram'=>'','vk'=>'','discord'=>'','youtube'=>'','logo'=>'','favicon'=>'','banner'=>'','apk_file'=>'','apk_size'=>'0','apk_date'=>'','downloads'=>'0'];
    $st=$pdo->prepare("REPLACE INTO settings(k,v) VALUES(?,?)"); foreach($d as $k=>$x)$st->execute([$k,(string)$x]);
    $cfg="<?php\nreturn ".var_export(['host'=>$v['host'],'name'=>$v['name'],'user'=>$v['user'],'pass'=>$dbpass],true).";\n";
    if(file_put_contents($root.'/config/config.php',$cfg)===false) throw new Exception('Не удалось записать config/config.php');
    file_put_contents($root.'/config/install.lock',date('c'));
    header('Location: ../admin/'); exit;
  }catch(Throwable $x){ $err=$x->getMessage(); }
}
?><!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Установка</title><link rel="stylesheet" href="../assets/css/style.css"></head>
<body class="adm"><main class="box wide"><h1>Установка сайта</h1>
<div class="panel"><h3>Проверка сервера</h3><?php foreach($checks as $l=>$c) echo '<p>'.($c?'<b style="color:#4ade80">OK</b>':'<b style="color:#f87171">Ошибка</b>').' &nbsp;'.$h($l).'</p>'; ?></div>
<?php if($err) echo '<div class="flash bad">'.$h($err).'</div>'; if($pass): ?>
<form method="post" class="panel"><h3>База данных MySQL</h3>
<label>Хост<input name="host" value="<?=$h($v['host'])?>" required></label>
<label>Имя базы<input name="name" value="<?=$h($v['name'])?>" required></label>
<label>Пользователь<input name="user" value="<?=$h($v['user'])?>" required></label>
<label>Пароль БД<input type="password" name="dbpass"></label>
<h3>Проект и администратор</h3>
<label>Название проекта<input name="project" value="<?=$h($v['project'])?>" required></label>
<label>Логин администратора<input name="login" value="<?=$h($v['login'])?>" required></label>
<label>Пароль (от 8 символов)<input type="password" name="apass" required minlength="8"></label>
<label>Повторите пароль<input type="password" name="apass2" required></label>
<button class="btn">Установить</button></form>
<?php else: echo '<div class="flash bad">Исправьте ошибки выше и обновите страницу.</div>'; endif; ?></main></body></html>
